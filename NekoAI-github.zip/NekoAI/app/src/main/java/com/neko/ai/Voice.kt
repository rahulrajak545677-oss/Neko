package com.neko.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Voice input with Android's built-in speech recognition. onText(text, isFinal); onEnd(errorMessageOrNull). */
class VoiceInput(
    private val ctx: Context,
    private val onText: (String, Boolean) -> Unit,
    private val onEnd: (String?) -> Unit
) {
    private var sr: SpeechRecognizer? = null

    fun start(lang: String) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onEnd("Speech recognition isn’t available on this phone."); return }
        stop()
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onPartialResults(b: Bundle?) { text(b)?.let { onText(it, false) } }
                override fun onResults(b: Bundle?) { val t = text(b); if (t == null) onEnd(null) else onText(t, true) }
                override fun onError(e: Int) {
                    onEnd(
                        if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                            "I didn’t catch that. Tap the mic and try again." else "Voice input failed (error $e)."
                    )
                }
            })
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            )
        }
    }

    fun stop() { sr?.destroy(); sr = null }

    private fun text(b: Bundle?) =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.takeIf { it.isNotBlank() }
}
