package com.neko.ai

import android.content.SharedPreferences
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun KeyDialog(prefs: SharedPreferences, onDone: () -> Unit) {
    var tf by remember { mutableStateOf(prefs.getString("tfKey", "").orEmpty()) }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text("TinyFish key") },
        text = {
            Column {
                Text("Get your API key at agent.tinyfish.ai/api-keys and paste it here. It is stored only on this phone.", fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(tf, { tf = it }, label = { Text("TinyFish API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                Spacer(Modifier.height(10.dp))
                Text("Questions and links use TinyFish Search and Fetch. Rewrites, screen explanations and web tasks run a TinyFish agent and use your TinyFish credits.", fontSize = 12.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                prefs.edit().putString("tfKey", tf.trim()).apply()
                onDone()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel") } }
    )
}
