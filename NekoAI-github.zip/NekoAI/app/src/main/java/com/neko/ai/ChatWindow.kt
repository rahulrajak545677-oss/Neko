package com.neko.ai

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class Msg(val mine: Boolean, val text: String)

private val BotBubble = Color(0xFF2A2640)
private val Panel = Color(0xF2100A20)

/** The floating chat window, styled after the picked mockup: boxed header, bubbles with cat avatars, chips, one pill input bar. */
@Composable
fun ChatWindow(state: ChatState, onMinimize: () -> Unit, onClose: () -> Unit, onWantInput: () -> Unit) {
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    var text by state::input
    val accent = NekoStyle.accent
    val shape = RoundedCornerShape(26.dp)

    LaunchedEffect(state.msgs.size, state.typing) {
        val last = state.msgs.size - 1 + (if (state.typing) 1 else 0)
        list.animateScrollToItem(last.coerceAtLeast(0))
    }
    fun send() {
        val t = text.trim()
        if (t.isNotEmpty()) { text = ""; scope.launch { state.send(t) } }
    }

    Column(
        Modifier.fillMaxSize().clip(shape).background(Panel)
            .border(2.dp, Brush.linearGradient(listOf(accent, Magenta.copy(alpha = .8f), accent)), shape)
            .drawBehind {   // little pixel accents on the frame, like the mockup
                val s = 6.dp.toPx()
                drawRect(accent.copy(alpha = .85f), Offset(size.width - 38.dp.toPx(), 7.dp.toPx()), Size(s, s))
                drawRect(accent.copy(alpha = .6f), Offset(18.dp.toPx(), size.height - 13.dp.toPx()), Size(s * .8f, s * .8f))
            }
    ) {
        // Header: its own rounded box
        val hs = RoundedCornerShape(18.dp)
        Row(
            Modifier.fillMaxWidth().padding(10.dp).clip(hs).border(1.dp, accent.copy(alpha = .45f), hs)
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(width = 46.dp, height = 40.dp)) {
                CatFace(true, accent, Modifier.fillMaxSize())
                Box(Modifier.size(12.dp).align(Alignment.BottomEnd).background(Color(0xFF22C55E), CircleShape).border(1.5.dp, Color(0xFF100A20), CircleShape))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Neko AI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(Modifier.width(6.dp))
                    Box(Modifier.size(16.dp).background(accent, CircleShape), contentAlignment = Alignment.Center) {
                        Text("✓", color = Color.White, fontSize = 10.sp)
                    }
                }
                Text("Online", color = Color(0xFFB9B2D6), fontSize = 12.sp)
            }
            Text("—", color = Color.White, fontSize = 20.sp, modifier = Modifier.tap("Minimize", onMinimize).padding(8.dp))
            Text("✕", color = Color.White, fontSize = 18.sp, modifier = Modifier.tap("Close", onClose).padding(8.dp))
        }

        // Messages
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = list,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(state.msgs) { MessageRow(it, accent) }
            if (state.typing) item { TypingDots() }
        }

        // Quick replies
        LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.chips()) { c ->
                Box(
                    Modifier.clip(CircleShape).border(1.dp, accent.copy(alpha = .75f), CircleShape)
                        .tap(c) { scope.launch { state.onChip(c) } }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) { Text(c, color = Color.White, fontSize = 13.sp) }
            }
        }

        // Input: one pill = message | mic | send
        Row(
            Modifier.fillMaxWidth().padding(10.dp).clip(CircleShape).border(1.5.dp, accent.copy(alpha = .7f), CircleShape).padding(start = 14.dp, top = 4.dp, end = 4.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BasicTextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
                modifier = Modifier.weight(1f).focusRequester(focus).pointerInput(Unit) {
                    // The overlay window starts non-focusable; make it focusable, then summon the keyboard.
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        onWantInput()
                        scope.launch { delay(150); focus.requestFocus(); keyboard?.show() }
                    }
                },
                decorationBox = { inner ->
                    if (text.isEmpty()) Text(if (state.listening) "Listening…" else "Message…", color = Muted, fontSize = 15.sp)
                    inner()
                }
            )
            Box(Modifier.width(1.dp).height(22.dp).background(Color(0x33FFFFFF)))
            Text(if (state.listening) "🔴" else "🎤", fontSize = 18.sp, modifier = Modifier.tap("Voice input") { state.voiceRequest?.invoke() }.padding(horizontal = 10.dp))
            RoundBtn("➤", accent) { send() }
        }
    }
}

@Composable
private fun RoundBtn(label: String, accent: Color, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).background(accent, CircleShape).tap("Send", onClick), contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontSize = 17.sp)
    }
}

@Composable
private fun MessageRow(m: Msg, accent: Color) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (m.mine) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Bottom
    ) {
        if (!m.mine) { CatFace(true, accent, Modifier.size(width = 32.dp, height = 28.dp)); Spacer(Modifier.width(8.dp)) }
        val bg = if (m.mine) Modifier.background(Brush.horizontalGradient(listOf(accent, Color(0xFF5B3FE0)))) else Modifier.background(BotBubble)
        Box(Modifier.widthIn(max = 250.dp).clip(RoundedCornerShape(18.dp)).then(bg).padding(horizontal = 14.dp, vertical = 9.dp)) {
            if (m.mine) Row(verticalAlignment = Alignment.Bottom) {
                Text(m.text, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f, fill = false))
                Spacer(Modifier.width(6.dp))
                Text("✓✓", color = Color(0xFFCFC6FF), fontSize = 10.sp)   // read ticks
            } else Text(m.text, color = Color.White, fontSize = 15.sp)
        }
    }
}

@Composable
private fun TypingDots() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(verticalAlignment = Alignment.Bottom) {
        CatFace(true, NekoStyle.accent, Modifier.size(width = 32.dp, height = 28.dp)); Spacer(Modifier.width(8.dp))
        Row(Modifier.clip(RoundedCornerShape(18.dp)).background(BotBubble).padding(horizontal = 16.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(3) { i ->
                val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(500, delayMillis = i * 150), RepeatMode.Reverse), label = "d$i")
                Box(Modifier.size(8.dp).alpha(a).background(Color.White, CircleShape))
            }
        }
    }
}
