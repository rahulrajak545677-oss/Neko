package com.neko.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Hit(val title: String, val snippet: String, val url: String)
data class Page(val title: String, val description: String, val text: String)

/**
 * The only AI backend of Neko. TinyFish has no chat model, so:
 *  - Search (fast): ranked web results.
 *  - Fetch  (fast): a web page as text.
 *  - Agent  (slower, uses credits): a browser agent that works toward a goal. [think] uses it as the writer
 *    for rewrites and explanations by pointing it at a plain page and giving it the text inside the goal.
 */
object TinyFishClient {
    /** A tiny static page. The agent only needs somewhere to stand while it writes. */
    private const val THINK_URL = "https://example.com"

    private fun describe(code: Int, raw: String): String {
        val detail = runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull().orEmpty()
        val base = when (code) {
            401, 403 -> "TinyFish rejected your API key. Check it under “AI keys”."
            402 -> "Your TinyFish wallet is empty. Add credits at agent.tinyfish.ai."
            429 -> "TinyFish rate limit reached. Try again in a moment."
            else -> "TinyFish error $code."
        }
        return if (detail.isBlank()) base else "$base $detail"
    }

    private fun http(url: String, key: String, post: String?, readMs: Int): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.setRequestProperty("X-API-Key", key)
            c.connectTimeout = 15000; c.readTimeout = readMs
            if (post != null) {
                c.requestMethod = "POST"; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(post.toByteArray()) }
            }
            val code = c.responseCode
            val raw = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText().orEmpty()
            if (code !in 200..299) error(describe(code, raw))
            return raw
        } finally { c.disconnect() }
    }

    /** Top 4 web results. */
    suspend fun search(key: String, query: String, lang: String): List<Hit> = withContext(Dispatchers.IO) {
        val raw = http("https://api.search.tinyfish.ai?query=${URLEncoder.encode(query, "UTF-8")}&language=$lang", key, null, 30000)
        val arr = JSONObject(raw).optJSONArray("results") ?: return@withContext emptyList()
        (0 until minOf(arr.length(), 4)).map {
            val r = arr.getJSONObject(it)
            Hit(r.optString("title"), r.optString("snippet"), r.optString("url"))
        }
    }

    /** One page as markdown text. */
    suspend fun fetch(key: String, url: String): Page = withContext(Dispatchers.IO) {
        val body = JSONObject().put("urls", JSONArray().put(url)).put("format", "markdown").toString()
        val j = JSONObject(http("https://api.fetch.tinyfish.ai", key, body, 120000))
        val r = j.optJSONArray("results")?.optJSONObject(0)
        if (r == null) {
            val why = j.optJSONArray("errors")?.optJSONObject(0)?.optString("error").orEmpty()
            error("I couldn’t open that page" + if (why.isBlank()) "." else " ($why).")
        }
        Page(r.optString("title"), r.optString("description"), r.optString("text"))
    }

    /** Runs the agent and returns its `result` as the API gave it (object, string or null). */
    private suspend fun runAgent(key: String, url: String, goal: String, maxSteps: Int, maxSeconds: Int): Any? = withContext(Dispatchers.IO) {
        val cfg = JSONObject().put("max_steps", maxSteps).put("max_duration_seconds", maxSeconds)
        val body = JSONObject().put("url", url).put("goal", goal).put("agent_config", cfg).toString()
        val j = JSONObject(http("https://agent.tinyfish.ai/v1/automation/run", key, body, (maxSeconds + 40) * 1000))
        val err = j.optJSONObject("error")
        if (err != null || j.optString("status") == "FAILED") {
            if (err?.optString("category") == "BILLING_FAILURE") error("Your TinyFish wallet is empty. Add credits at agent.tinyfish.ai.")
            error(err?.optString("message").orEmpty().ifBlank { "The agent couldn’t finish that." })
        }
        j.opt("result")
    }

    /** A goal on a real website, answered as readable text. */
    suspend fun agent(key: String, url: String, goal: String, maxSteps: Int, maxSeconds: Int): String =
        show(runAgent(key, url, goal, maxSteps, maxSeconds)).trim().ifBlank { "The agent finished but returned nothing." }

    /** Writing help (rewrite, explain): the instruction and its text go inside the goal; the agent just writes. */
    suspend fun think(key: String, instruction: String): String {
        val goal = "This is a pure writing task. Do not click, search or browse; use only the text below. " +
            "Return the final answer as JSON with one field named \"text\".\n\n$instruction"
        return unwrap(runAgent(key, THINK_URL, goal, 6, 60)).ifBlank { "I couldn’t come up with an answer. Try again." }
    }

    private fun unwrap(v: Any?): String {
        if (v is JSONObject) {
            for (k in listOf("text", "answer", "result", "summary", "output")) {
                val s = v.opt(k)
                if (s is String && s.isNotBlank()) return s.trim()
            }
        }
        return show(v).trim()
    }

    /** JSON to plain lines, so web-task results read like text. */
    private fun show(v: Any?): String = when (v) {
        null, JSONObject.NULL -> ""
        is String -> v
        is JSONObject -> v.keys().asSequence().joinToString("\n") { k ->
            val x = v.opt(k)
            if (x is String || x is Number || x is Boolean) "$k: $x" else "$k:\n" + show(x).prependIndent("  ")
        }
        is JSONArray -> (0 until v.length()).joinToString("\n") { "• " + show(v.opt(it)).replace("\n", " ") }
        else -> v.toString()
    }
}
