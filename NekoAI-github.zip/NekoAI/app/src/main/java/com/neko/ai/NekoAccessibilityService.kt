package com.neko.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Reads on-screen text only when the bubble is tapped (snapshot), and can write a rewrite back into the focused field. */
class NekoAccessibilityService : AccessibilityService() {
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    companion object {
        var instance: NekoAccessibilityService? = null
        var screen: String? = null
        var draft: String? = null

        /** Call right when the bubble is tapped, while the other app is still in front. */
        fun snapshot() {
            val root = instance?.rootInActiveWindow ?: return
            val sb = StringBuilder(); var d: String? = null
            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null || sb.length > 6000 || n.isPassword) return   // never read password fields
                n.text?.let { sb.append(it).append('\n'); if (n.isEditable && n.isFocused) d = it.toString() }
                for (i in 0 until n.childCount) walk(n.getChild(i))
            }
            walk(root); screen = sb.toString(); draft = d
        }

        fun setDraft(text: String): Boolean {
            val s = instance ?: return false
            val roots = s.windows.mapNotNull { it.root }.filter { it.packageName != s.packageName } + listOfNotNull(s.rootInActiveWindow)
            for (r in roots) {
                val n = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: continue
                val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
                return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            }
            return false
        }
    }
}
