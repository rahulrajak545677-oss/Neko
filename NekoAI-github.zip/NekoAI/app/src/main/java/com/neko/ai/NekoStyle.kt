package com.neko.ai

import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import kotlin.math.cos
import kotlin.math.sin

/** The cat's current mood and neon skin, shared by the app, the bubble and the chat window. */
object NekoStyle {
    var mood by mutableStateOf("Happy")
    var hue by mutableStateOf(0f)
    var accent by mutableStateOf(Color(0xFF8B5CF6))

    fun load(p: SharedPreferences) {
        mood = p.getString("mood", "Happy").orEmpty()
        hue = p.getFloat("hue", 0f)
        accent = Color(p.getInt("accent", 0xFF8B5CF6.toInt()))
    }

    fun save(p: SharedPreferences) =
        p.edit().putString("mood", mood).putFloat("hue", hue).putInt("accent", accent.toArgb()).apply()

    /** Off = eyes closed. On = the picked mood. */
    fun res(on: Boolean): Int = if (!on) R.drawable.neko_cat_off else when (mood) {
        "Sleepy" -> R.drawable.neko_cat_sleepy
        "Excited" -> R.drawable.neko_cat_excited
        "Thinking" -> R.drawable.neko_cat_thinking
        else -> R.drawable.neko_cat
    }

    /** 4x5 colour matrix that rotates hue (turns the violet neon into cyan, pink, green...). */
    fun hueMatrix(deg: Float): FloatArray {
        val r = Math.toRadians(deg.toDouble()); val c = cos(r).toFloat(); val s = sin(r).toFloat()
        return floatArrayOf(
            0.213f + c * 0.787f - s * 0.213f, 0.715f - c * 0.715f - s * 0.715f, 0.072f - c * 0.072f + s * 0.928f, 0f, 0f,
            0.213f - c * 0.213f + s * 0.143f, 0.715f + c * 0.285f + s * 0.140f, 0.072f - c * 0.072f - s * 0.283f, 0f, 0f,
            0.213f - c * 0.213f - s * 0.787f, 0.715f - c * 0.715f + s * 0.715f, 0.072f + c * 0.928f + s * 0.072f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        )
    }
}
