package com.neko.ai

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics

/**
 * A tap with no visual marking: no ripple, no pressed overlay, no focus box.
 * Like an accessibility button, it is exposed to the system as a plain "Button" with a click action,
 * so TalkBack and Switch Access can still activate it.
 */
@Composable
fun Modifier.tap(label: String? = null, action: () -> Unit): Modifier {
    val latest by rememberUpdatedState(action)
    return this
        .semantics(mergeDescendants = true) {
            role = Role.Button
            onClick(label) { latest(); true }
        }
        .pointerInput(Unit) { detectTapGestures { latest() } }
}
