package com.neko.ai

import android.content.SharedPreferences

/** Reads the settings the chat needs: the TinyFish key, the reply tone and the reply language. */
class AiHelper(private val prefs: SharedPreferences) {
    fun tfKey(): String = prefs.getString("tfKey", "").orEmpty()
    fun tone(): String = prefs.getString("tone", "Friendly").orEmpty()
    fun lang(): String = prefs.getString("lang", "English").orEmpty()

    /** Language code for TinyFish Search results. */
    fun langCode(): String = when (lang()) {
        "Hindi" -> "hi"
        "Spanish" -> "es"
        "French" -> "fr"
        "Arabic" -> "ar"
        else -> "en"
    }

    /** One line added to every agent goal so replies follow the Settings sheet. */
    fun style(): String = "Tone: ${tone()}. Reply in ${lang()}."
}
