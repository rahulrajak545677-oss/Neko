package com.neko.ai

import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SKINS = listOf(0f to Color(0xFF8B5CF6), -80f to Color(0xFF22D3EE), 45f to Color(0xFFF472B6), -150f to Color(0xFF4ADE80), 100f to Color(0xFFFB923C))

@Composable
private fun Pill(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(Modifier.clip(CircleShape).background(if (selected) Violet else Color(0x14FFFFFF)).tap(label, onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsSheet(prefs: SharedPreferences, onDone: () -> Unit) {
    var size by remember { mutableStateOf(prefs.getInt("size", 64).toFloat()) }
    var tone by remember { mutableStateOf(prefs.getString("tone", "Friendly").orEmpty()) }
    var lang by remember { mutableStateOf(prefs.getString("lang", "English").orEmpty()) }
    var wide by remember { mutableStateOf(prefs.getFloat("chatW", 0.78f) > 0.9f) }
    ModalBottomSheet(onDismissRequest = onDone, containerColor = Color(0xFF120B22)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 32.dp)) {
            Text("Bubble & AI", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Text("Bubble size · ${size.toInt()} dp", color = Muted, fontSize = 13.sp)
            Slider(size, { size = it; prefs.edit().putInt("size", it.toInt()).apply() }, valueRange = 40f..96f)
            Spacer(Modifier.height(8.dp))
            Text("Writing tone", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Professional", "Casual", "Friendly", "Funny").forEach { t ->
                    Pill(t, tone == t) { tone = t; prefs.edit().putString("tone", t).apply() }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Reply language", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("English", "Hindi", "Spanish", "French", "Arabic").forEach { l ->
                    Pill(l, lang == l) { lang = l; prefs.edit().putString("lang", l).apply() }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Chat window", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("Compact (corner)", !wide) { wide = false; prefs.edit().putFloat("chatW", 0.78f).apply() }
                Pill("Wide", wide) { wide = true; prefs.edit().putFloat("chatW", 0.96f).apply() }
            }
            Spacer(Modifier.height(16.dp))
            Text("Cat mood", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Happy", "Sleepy", "Excited", "Thinking").forEach { m ->
                    Pill(m, NekoStyle.mood == m) { NekoStyle.mood = m; NekoStyle.save(prefs) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("Neon skin", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SKINS.forEach { (hue, col) ->
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(col)
                            .border(if (NekoStyle.hue == hue) 3.dp else 0.dp, Color.White, CircleShape)
                            .tap("Neon skin") { NekoStyle.hue = hue; NekoStyle.accent = col; NekoStyle.save(prefs) }
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("Size, mood and skin reach the floating bubble the next time you switch Neko on.", color = Muted, fontSize = 12.sp)
        }
    }
}
