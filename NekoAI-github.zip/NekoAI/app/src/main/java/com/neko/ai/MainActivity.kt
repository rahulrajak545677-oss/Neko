package com.neko.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { NekoApp() }
    }
}

private fun readPerms(ctx: Context, prefs: android.content.SharedPreferences): List<Boolean> {
    val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
    return listOf(
        Settings.canDrawOverlays(ctx),                                   // Overlay
        enabled?.contains(ctx.packageName) == true,                      // Reader (accessibility)
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    )
}

@Composable
fun NekoApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("neko", Context.MODE_PRIVATE) }
    remember(prefs) { NekoStyle.load(prefs) }
    var on by remember { mutableStateOf(prefs.getBoolean("on", false)) }
    var perms by remember { mutableStateOf(readPerms(ctx, prefs)) }
    var showKey by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var keySet by remember { mutableStateOf(!prefs.getString("tfKey", "").isNullOrBlank()) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { perms = readPerms(ctx, prefs) }
    val svc = Intent(ctx, BubbleService::class.java)

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        perms = readPerms(ctx, prefs)
        if (on && !perms[0]) { on = false; prefs.edit().putBoolean("on", false).apply(); ctx.stopService(svc) }
    }

    NekoHome(on, perms, keySet, { showKey = true }, { showSettings = true }, onPower = {
        when {
            !perms[0] -> {
                Toast.makeText(ctx, "Allow “Display over other apps” first", Toast.LENGTH_SHORT).show()
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }
            !on && Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED ->
                ask.launch(Manifest.permission.POST_NOTIFICATIONS)
            else -> {
                on = !on
                prefs.edit().putBoolean("on", on).apply()
                if (on) ContextCompat.startForegroundService(ctx, svc) else ctx.stopService(svc)
            }
        }
    }, onPerm = { i ->
        when (i) {
            0 -> ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            1 -> ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            2 -> ask.launch(Manifest.permission.RECORD_AUDIO)
        }
    })
    if (showSettings) SettingsSheet(prefs) { showSettings = false }
    if (showKey) KeyDialog(prefs) { showKey = false; keySet = !prefs.getString("tfKey", "").isNullOrBlank() }
}
