package com.neko.ai

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException

/**
 * Routing (TinyFish only):
 *  - plain question or "🔎 Search the web"  -> Search API
 *  - a link alone                           -> Fetch API (page preview)
 *  - a link plus words, or "🌐 Web task"    -> Agent on that site
 *  - write / reply / rewrite / explain ...  -> Agent as the writer (see TinyFishClient.think)
 */
class ChatState(private val ai: AiHelper) {
    val msgs = mutableStateListOf(Msg(false, "Hi! How can I help you?"))
    var typing by mutableStateOf(false)
    private var pending by mutableStateOf<String?>(null)   // last rewrite, waiting to be applied
    private var mode by mutableStateOf<String?>(null)      // "search" or "task": the next message is the query

    private val urlRe = Regex("https?://\\S+")
    private val writeRe = Regex(
        "^(write|reply|draft|rewrite|translate|summari[sz]e|explain|fix|correct|improve|shorten|make|compose|paraphrase)\\b",
        RegexOption.IGNORE_CASE
    )
    var input by mutableStateOf("")                 // text in the message box (voice input writes here too)
    var listening by mutableStateOf(false)
    var voiceRequest: (() -> Unit)? = null          // set by BubbleService

    private val needKey = "Add your TinyFish key first: tap “AI keys” in the Neko app."

    fun chips() = listOf("Make it professional", "Make it shorter", "Add emojis ✨", "Explain screen", "🔎 Search the web", "🌐 Web task") +
        listOfNotNull(if (pending != null) "Apply to text field" else null)

    suspend fun send(text: String) {
        msgs.add(Msg(true, text))
        val m = mode; mode = null
        reply { k ->
            when {
                m == "search" -> search(k, text)
                m == "task" -> task(k, text)
                urlRe.containsMatchIn(text) -> readPage(k, text)   // a link in your message: Neko reads the page
                writeRe.containsMatchIn(text.trim()) -> write(k, text, NekoAccessibilityService.screen)
                else -> search(k, text)
            }
        }
    }

    suspend fun onChip(c: String) {
        msgs.add(Msg(true, c))
        when {
            c.startsWith("🔎") -> { mode = "search"; msgs.add(Msg(false, "What should I search for?")) }
            c.startsWith("🌐") -> {
                mode = "task"
                msgs.add(Msg(false, "Tell me the website and what to do, like: example.com find the cheapest plan"))
            }
            c.startsWith("Apply") -> reply(needsKey = false) {
                val ok = pending?.let { NekoAccessibilityService.setDraft(it) } == true
                if (ok) { pending = null; "Done! I replaced your text. ✅" } else "I couldn’t edit that field. Copy the text above instead."
            }
            c.startsWith("Explain") -> reply { k ->
                val screen = NekoAccessibilityService.screen
                if (screen.isNullOrBlank()) {
                    "I can’t read the screen. Turn on “Reader” in the Neko app, then tap my bubble again."
                } else {
                    TinyFishClient.think(k, "Explain in under 80 words what is on this screen and what the user can do here. ${ai.style()}\n\nScreen text:\n${screen.take(5000)}")
                }
            }
            else -> reply { k ->
                val draft = NekoAccessibilityService.draft
                if (draft.isNullOrBlank()) return@reply "I can’t see your draft. Tap into the text box, then tap my bubble and try again."
                val style = when {
                    c.contains("profess", true) -> "more professional"
                    c.contains("short", true) -> "shorter"
                    else -> "friendlier, with fitting emojis"
                }
                val out = TinyFishClient.think(k, "Rewrite this text to be $style. ${ai.style()} Return only the rewritten text.\n\nText:\n$draft")
                pending = out
                out
            }
        }
    }

    // ---- TinyFish routes ----

    private suspend fun search(k: String, q: String): String {
        val hits = TinyFishClient.search(k, q, ai.langCode())
        if (hits.isEmpty()) return "I found no results for that."
        val top = hits.first().snippet.ifBlank { hits.first().title }
        val sources = hits.mapIndexed { i, h -> "${i + 1}. ${h.title}\n${h.url}" }.joinToString("\n\n")
        return "$top\n\nSources:\n$sources"
    }

    private suspend fun readPage(k: String, text: String): String {
        val url = urlRe.find(text)!!.value
        val ask = text.replace(url, "").trim()
        if (ask.isNotEmpty()) return TinyFishClient.agent(k, url, "$ask. ${ai.style()} Be concise.", 25, 100)
        val p = TinyFishClient.fetch(k, url)
        val body = p.text.replace(Regex("\\s+"), " ").take(500)
        return listOf(p.title, p.description, body).filter { it.isNotBlank() }.joinToString("\n\n")
    }

    private suspend fun task(k: String, text: String): String {
        val parts = text.trim().split(" ", limit = 2)
        val url = parts[0].let { if (it.startsWith("http")) it else "https://$it" }
        val goal = parts.getOrElse(1) { "Summarize this page" }
        return TinyFishClient.agent(k, url, "$goal. ${ai.style()}", 40, 120)
    }

    private suspend fun write(k: String, text: String, screen: String?): String {
        val context = if (screen.isNullOrBlank()) "" else "\n\nScreen text for context:\n${screen.take(5000)}"
        return TinyFishClient.think(k, "${ai.style()} Be concise (under 80 words).\n\nRequest: $text$context")
    }

    private suspend fun reply(needsKey: Boolean = true, block: suspend (String) -> String) {
        typing = true
        val k = ai.tfKey()
        val r = try {
            if (needsKey && k.isBlank()) needKey else block(k)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            "Something went wrong: ${e.message}"
        } finally {
            typing = false
        }
        msgs.add(Msg(false, r))
    }
}
