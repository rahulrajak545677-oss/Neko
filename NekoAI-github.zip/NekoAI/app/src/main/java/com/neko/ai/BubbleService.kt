package com.neko.ai

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.ColorMatrixColorFilter
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import kotlin.math.abs

/** Foreground service: draggable cat bubble + the floating chat window. */
class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var owner: OverlayOwner
    private var bubble: BubbleView? = null
    private var chat: ComposeView? = null
    private var chatLp: WindowManager.LayoutParams? = null
    private val prefs by lazy { getSharedPreferences("neko", MODE_PRIVATE) }
    private lateinit var chatState: ChatState
    private val scope = MainScope()
    private var voice: VoiceInput? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        owner = OverlayOwner()
        NekoStyle.load(prefs)
        chatState = ChatState(AiHelper(prefs)); wire()
        goForeground()
        addBubble()
    }

    private fun goForeground() {
        val ch = "neko"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Neko AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Neko is online")
            .setContentText("Tap the cat bubble to chat").setSmallIcon(android.R.drawable.ic_dialog_info).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun addBubble() {
        val w = (prefs.getInt("size", 64) * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            w, (w / 1.162f).toInt(), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 0; y = 300 }
        bubble = BubbleView(this, lp, wm) { if (chat == null) showChat() else hideChat() }
        wm.addView(bubble, lp)
    }

    private fun showChat() {
        if (chat != null) return
        NekoAccessibilityService.snapshot()   // read the screen now, while the other app is in front
        val dm = resources.displayMetrics
        val margin = (12 * dm.density).toInt()
        val lp = WindowManager.LayoutParams(
            (dm.widthPixels * prefs.getFloat("chatW", 0.78f)).toInt(), (dm.heightPixels * 0.52f).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.END
            x = margin; y = margin
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeViewModelStoreOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setContent {
                ChatWindow(
                    state = chatState,
                    onMinimize = { hideChat() },
                    onClose = { voice?.stop(); chatState = ChatState(AiHelper(prefs)); wire(); hideChat() },
                    onWantInput = { makeChatFocusable() }
                )
            }
        }
        chat = view; chatLp = lp
        wm.addView(view, lp)   // the cat bubble stays visible next to the chat, like the mockup
    }

    /** Overlay windows only get a keyboard once FLAG_NOT_FOCUSABLE is cleared. */
    private fun makeChatFocusable() {
        val lp = chatLp ?: return
        val v = chat ?: return
        if (lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE != 0) {
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
            wm.updateViewLayout(v, lp)
        }
    }

    private fun wire() {
        chatState.voiceRequest = { toggleVoice() }
    }

    /** 🎤: listen, show the words live in the message box, send when you stop talking. */
    private fun toggleVoice() {
        if (chatState.listening) { voice?.stop(); chatState.listening = false; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            chatState.msgs.add(Msg(false, "Allow the microphone first: open the Neko app and tap “Mic”.")); return
        }
        val lang = mapOf("Hindi" to "hi-IN", "Spanish" to "es-ES", "French" to "fr-FR", "Arabic" to "ar-SA")[prefs.getString("lang", "English")] ?: "en-US"
        chatState.listening = true
        voice = VoiceInput(this, { text, final ->
            chatState.input = text
            if (final) {
                chatState.listening = false
                val t = text.trim(); chatState.input = ""
                if (t.isNotEmpty()) scope.launch { chatState.send(t) }
            }
        }, { err -> chatState.listening = false; err?.let { chatState.msgs.add(Msg(false, it)) } })
        voice?.start(lang)
    }

    private fun hideChat() {
        chat?.let { it.disposeComposition(); wm.removeView(it) }
        chat = null; chatLp = null
        bubble?.visibility = View.VISIBLE
    }

    override fun onDestroy() {
        hideChat()
        bubble?.let { wm.removeView(it) }
        voice?.stop(); scope.cancel()
        owner.destroy()
        super.onDestroy()
    }
}

@SuppressLint("ViewConstructor")
class BubbleView(
    ctx: Context, private val lp: WindowManager.LayoutParams,
    private val wm: WindowManager, private val onTap: () -> Unit
) : View(ctx) {
    private var downX = 0f; private var downY = 0f; private var startX = 0; private var startY = 0
    private var moved = false
    private val bmp = BitmapFactory.decodeResource(ctx.resources, NekoStyle.res(true))
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG).apply {
        if (NekoStyle.hue != 0f) colorFilter = ColorMatrixColorFilter(NekoStyle.hueMatrix(NekoStyle.hue))
    }

    init {
        // A plain, mark-free button like an accessibility button: nothing is drawn on tap
        // (no focus ring, no pressed box, no ripple), but accessibility services can still click it.
        isFocusable = false
        isFocusableInTouchMode = false
        defaultFocusHighlightEnabled = false
        background = null
        foreground = null
        isClickable = true
        isHapticFeedbackEnabled = false
        contentDescription = "Neko AI. Double tap to open the chat."
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    override fun onDraw(canvas: Canvas) { canvas.drawBitmap(bmp, null, Rect(0, 0, width, height), paint) }

    /** Fires on a real tap and when an accessibility service clicks the bubble. No sound, no highlight. */
    override fun performClick(): Boolean { onTap(); return true }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX; val dy = e.rawY - downY
                if (abs(dx) > 8 || abs(dy) > 8) moved = true
                lp.x = startX - dx.toInt()   // gravity END: x grows leftwards
                lp.y = startY + dy.toInt()
                wm.updateViewLayout(this, lp)
            }
            MotionEvent.ACTION_UP -> if (!moved) performClick()
        }
        return true
    }
}
