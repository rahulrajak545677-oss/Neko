package com.neko.ai

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Violet = Color(0xFF8B5CF6)
val Magenta = Color(0xFFE879F9)
val Void = Color(0xFF07040F)
val Muted = Color(0xFF9B90C4)
private val Gold1 = Color(0xFFF5D77A)
private val Gold2 = Color(0xFFE0A93B)

/** The cat from the picked mockup. Off = eyes closed. The mood picks the face; the skin rotates the neon colour. */
@Composable
fun CatFace(on: Boolean, accent: Color, modifier: Modifier = Modifier) {
    Image(
        painterResource(NekoStyle.res(on)), "Neko", modifier, contentScale = ContentScale.Fit,
        colorFilter = if (NekoStyle.hue == 0f) null else ColorFilter.colorMatrix(ColorMatrix(NekoStyle.hueMatrix(NekoStyle.hue)))
    )
}

/** Rotating rings, twinkling pixels and the cat. Tap: the face flips 360 degrees, then onTap fires mid-flip. */
@Composable
fun NekoOrb(on: Boolean, accent: Color, onTap: () -> Unit) {
    val t = rememberInfiniteTransition(label = "orb")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "spin")
    val back by t.animateFloat(0f, -360f, infiniteRepeatable(tween(16000, easing = LinearEasing)), label = "back")
    val bob by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob")
    val tw by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600), RepeatMode.Reverse), label = "tw")
    val ringAlpha by animateFloatAsState(if (on) 1f else 0.28f, label = "ring")
    val flip = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    Box(
        Modifier.size(260.dp).tap(if (on) "Switch Neko off" else "Wake Neko") {
            scope.launch {
                launch { flip.animateTo(360f, tween(900)); flip.snapTo(0f) }
                delay(450); onTap()
            }
        },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize().alpha(ringAlpha)) {
            val sw = 4.dp.toPx()
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = .35f), Color.Transparent)), size.minDimension / 2.2f)
            rotate(spin) {
                drawArc(
                    Brush.sweepGradient(listOf(Color.Transparent, accent, Magenta, Color.Transparent)),
                    0f, 360f, false, topLeft = Offset(sw / 2, sw / 2),
                    size = Size(size.width - sw, size.height - sw), style = Stroke(sw)
                )
            }
            rotate(back) {
                drawCircle(
                    accent.copy(alpha = .65f), size.minDimension / 2 - 24.dp.toPx(),
                    style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f)))
                )
            }
            rotate(spin * 1.6f) {
                drawRect(Color(0xFF22D3EE), Offset(center.x - 4.5.dp.toPx(), 5.dp.toPx()), Size(9.dp.toPx(), 9.dp.toPx()))
            }
            // floating pixel squares, like the mockup
            listOf(Offset(.93f, .2f), Offset(.04f, .32f), Offset(.88f, .84f), Offset(.1f, .88f), Offset(.52f, .0f)).forEachIndexed { i, p ->
                val sz = (if (i % 2 == 0) 8 else 5).dp.toPx()
                drawRect(accent.copy(alpha = .25f + .6f * (if (i % 2 == 0) tw else 1f - tw)), Offset(p.x * size.width, p.y * size.height), Size(sz, sz))
            }
        }
        CatFace(
            on, accent,
            Modifier.width(190.dp).height(164.dp).graphicsLayer {
                rotationY = flip.value
                cameraDistance = 12f * density
                translationY = -8.dp.toPx() * bob
            }
        )
    }
}

@Composable
fun PermChip(name: String, ok: Boolean, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Row(
        modifier.clip(shape).border(1.dp, if (ok) accent else Color(0x1CFFFFFF), shape)
            .background(Color(0x0DFFFFFF)).tap(name, onClick).padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(if (ok) Color(0xFF4ADE80) else Color(0x33FFFFFF), CircleShape))
        Spacer(Modifier.width(6.dp))
        Text(name, color = Color.White, fontSize = 12.sp)
    }
}

@Composable
private fun GlassTile(modifier: Modifier, icon: String, title: String, sub: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.clip(shape)
            .border(1.dp, Brush.linearGradient(listOf(Violet.copy(alpha = .7f), Color(0x22FFFFFF))), shape)
            .background(Color(0x0DFFFFFF)).tap(title, onClick).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(icon, fontSize = 22.sp)
        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(sub, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun NekoHome(
    on: Boolean, perms: List<Boolean>, keySet: Boolean,
    onKey: () -> Unit, onSettings: () -> Unit, onPower: () -> Unit, onPerm: (Int) -> Unit
) {
    val names = listOf("Overlay", "Reader", "Mic")
    Column(
        Modifier.fillMaxSize().drawBehind {
            drawRect(Void)
            val c = Offset(size.width / 2f, 0f)
            drawCircle(Brush.radialGradient(listOf(Violet.copy(alpha = .32f), Color.Transparent), c, size.width * .9f), size.width * .9f, c)
        }.statusBarsPadding().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Neko AI", style = TextStyle(brush = Brush.horizontalGradient(listOf(Color.White, Magenta)), fontSize = 22.sp, fontWeight = FontWeight.Bold))
            Box(Modifier.clip(CircleShape).background(Brush.horizontalGradient(listOf(Gold1, Gold2))).padding(horizontal = 12.dp, vertical = 4.dp)) {
                Text("PREMIUM", color = Color(0xFF2A1A00), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
        NekoOrb(on, NekoStyle.accent, onPower)
        Text(if (on) "Neko is online" else "Neko is asleep", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(if (on) "Tap the cat to switch off" else "Tap the cat to wake Neko", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            names.forEachIndexed { i, n -> PermChip(n, perms[i], NekoStyle.accent, Modifier.weight(1f)) { onPerm(i) } }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            GlassTile(Modifier.weight(1f), "⚙️", "Bubble & AI", "Size · tone · language", onSettings)
            GlassTile(Modifier.weight(1f), "🔑", "AI keys", if (keySet) "TinyFish connected" else "Add TinyFish key", onKey)
        }
    }
}
