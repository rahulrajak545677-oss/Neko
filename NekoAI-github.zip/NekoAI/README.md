# Neko AI

A floating cat assistant for Android: tap the cat bubble over any app, and Neko reads the screen, fixes your writing, searches the web and reads pages.
Powered only by **TinyFish** (Search, Fetch and Agent APIs). No Gemini.

## Run it
1. Install Android Studio (Ladybug or newer). Open this folder (`NekoAI`) and let Gradle sync.
2. Run on a phone with Android 8.0+ (a real device is best; overlays are limited on emulators).
3. In the app, tap the chips to grant **Overlay**, **Reader** (turn on Neko in Accessibility settings) and **Mic**.
4. Tap **AI keys** and paste your TinyFish key from https://agent.tinyfish.ai/api-keys.
5. Tap the cat to wake Neko, then tap the floating cat inside any app to chat.

## Get an APK from GitHub (no Android Studio needed)
1. Put the contents of this folder at the root of a GitHub repo (`.github/`, `app/`, `gradlew` ... must sit at the top level).
2. GitHub builds on every push to `main`. You can also open the **Actions** tab > **Build APK** > **Run workflow**.
3. When the run is green, open it and download **NekoAI-debug-apk** under *Artifacts* (a zip with `NekoAI-debug.apk` inside).
4. Install it on your phone (allow "install unknown apps" once).
5. Optional: push a tag like `v0.1` and the APK is also attached to a GitHub Release, which gives you a download link you can share.

If the run is red, open the failed step and read the first `e: ...` line: that is a Kotlin compile error with the file and line.
The APK is a debug build (signed with Android's debug key). A Play Store release needs your own keystore.

## How Neko uses TinyFish
TinyFish has no chat model, so each job goes to the API that fits it:

| You do this | TinyFish API | Cost / speed |
|---|---|---|
| Type a question, or tap 🔎 Search the web | Search | fast |
| Send a link on its own | Fetch (page preview) | fast |
| Send a link plus words ("https://x.com what does it cost?"), or tap 🌐 Web task | Agent on that site | slower, uses credits |
| Start with write / reply / rewrite / translate / summarize / explain / fix, or tap a rewrite chip or "Explain screen" | Agent as the writer (`TinyFishClient.think`) | slower, uses credits |

- The agent is a browser agent, not a language model. For writing help it is pointed at `https://example.com` and told to use only the text in the goal. If you find the results flaky, this is the part to revisit (`TinyFishClient.think`).
- Reply tone and language from Settings are added to every agent goal; the language also picks the Search result language.

## Notes
- Not compiled by the author or the assistant that edited it: expect to fix a small error or two on first build.
- Neko reads the screen only when you tap the bubble and skips password fields. Screen text is sent to TinyFish only for "Explain screen" and for writing requests.
- The key is stored on the phone only. If you ever publish this app, move it to a backend.
- 📷 screenshots were removed: TinyFish cannot read images.
- 🎤 uses Android's built-in speech recognition; the language follows your reply-language setting. Allow the **Mic** chip first.
- The chat window opens bottom-right (Settings: Compact or Wide) and the cat bubble stays visible beside it.
- Taps have no visual marking (no ripple, pressed box or focus ring). Everything uses `Modifier.tap` (`Tap.kt`), and the floating bubble is a plain accessibility-clickable view.
- Cat looks: off = eyes closed; Settings has mood (Happy, Sleepy, Excited, Thinking) and neon skin (Violet, Cyan, Pink, Green, Orange).
